package com.fernandoherrarte.RepuestosAutomotrices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploApplicationTests {

	@Test
	void contextLoads() {
	}

}
